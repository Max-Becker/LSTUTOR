import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import javax.swing.border.EmptyBorder;



public class Assessor extends JPanel implements ActionListener
{
	 JPanel top, top2, top3, top4, inner,inner2,inner3,inner4, name;
	public JButton click, click1,click2 ;
	public JTextField type ;
	public JComboBox<String> box;
	 private JCheckBox select1, select2, select3;
	private  JLabel q1, q2, q3, q4;
	private JFrame frame;
	private int state;
	
	public static void main(String[] args)
	{
		
	}
	public Assessor()
	{
		name = new JPanel();
		name.add(new JLabel("Darren Sims"));
		//Layout and initialization for PANEL 1!!
		top = new JPanel();
		top.setBackground(Color.BLUE);
		top.setBorder(BorderFactory.createLineBorder(Color.BLACK,4));
		top.setLayout(new BorderLayout());
		top.setPreferredSize(new Dimension(292,192));
		inner = new JPanel();
		inner.setLayout(new BoxLayout(inner, BoxLayout.Y_AXIS));
		inner.setPreferredSize(new Dimension(top.getHeight(), top.getWidth()));
		//int heightInner = (int)((int)top.getHeight()*.15);
		//int widthInner = (int)((int)top.getWidth()*.15);
		inner.setBorder(new EmptyBorder(44,29,44,29));
		//Layout and initialization for PANEL 2!!
		top2 = new JPanel();
		top2.setBackground(Color.GREEN);
		top2.setPreferredSize(new Dimension(292,192));
		inner2 = new JPanel();
		inner2.setLayout(new BoxLayout(inner2, BoxLayout.Y_AXIS));
		//int heightInner2 = (int)((int)frame.getHeight()*.1);
		//int widthInner2 = (int)((int)frame.getWidth()*.16);
		inner2.setBorder(new EmptyBorder(40,96,44,96));
		top2.setBorder(BorderFactory.createLineBorder(Color.BLACK,4));
		top2.setLayout(new BorderLayout());
		//Layout and initialization for PANEL 3!!
		top3 = new JPanel();
		top3.setBackground(Color.GRAY);
		top3.setLayout(new BorderLayout());
		top3.setPreferredSize(new Dimension(292,192));
		inner3 = new JPanel();
		inner3.setLayout(new BoxLayout(inner3, BoxLayout.Y_AXIS));
		inner3.setAlignmentX(JComponent.CENTER_ALIGNMENT);
		inner3.setBorder(new EmptyBorder(40,96,44,96));
		top3.setBorder(BorderFactory.createLineBorder(Color.BLACK,4));
		//Layout and initialization for PANEL 4!!
		top4 = new JPanel();
		top4.setBackground(Color.YELLOW);
		top4.setBorder(BorderFactory.createLineBorder(Color.BLACK,4));
		top4.setLayout(new BorderLayout());
		top4.setPreferredSize(new Dimension(292,192));
		inner4 = new JPanel();
		inner4.setLayout(new BoxLayout(inner4, BoxLayout.Y_AXIS));
		inner4.setBorder(new EmptyBorder(50, 72,50,72));
		
		//Creates my Question labels
		q1 = new JLabel("Question 1");
		q2 = new JLabel("Question 2");
		q3 = new JLabel("Question 3");
		q4 = new JLabel("Question 4");
		
		//Creates checkbox's
		select1 = new JCheckBox("Option 1");
		
		select2 = new JCheckBox("Option 2");
	
		select3 = new JCheckBox("Option 3");
		
		
		
		//initializes JButtons and size of them
		click = new JButton("Option 1"); 
		click.setSize(30,20);
		
		click1 = new JButton("Option 2");
		click1.setSize(30, 20);
		
		click2 = new JButton("Option 3");
		click2.setSize(30,20);
		
		String[] Q_options = new String[] {"Option 1", "Option 2", "Option 3"};
		box = new JComboBox<String>(Q_options);
		box.addActionListener(this);
		top.add(q1, BorderLayout.NORTH);
		inner.add(box);
		top.add(inner);
		
		top2.add(q2, BorderLayout.NORTH);
		inner2.add(select1);
		inner2.add(select2);
		inner2.add(select3);
		select1.addActionListener(this);
		select2.addActionListener(this);
		select3.addActionListener(this);
		top2.add(inner2);
		
		top3.add(q3, BorderLayout.NORTH);
		inner3.add(click);
		inner3.add(Box.createRigidArea(new Dimension(0,10)));
		inner3.add(click1);
		inner3.add(Box.createRigidArea(new Dimension(0,10)));
		inner3.add(click2);
		click.addActionListener(this);
		click1.addActionListener(this);
		click2.addActionListener(this);
		top3.add(inner3);
		
		type = new JTextField("Write your answer here....");
		type.addActionListener(this);
		top4.add(q4, BorderLayout.NORTH);
		inner4.add(type);
		top4.add(inner4);
		
		name.setVisible(true);
		this.add(name);
		
		//setLayout(new );
		//Chooses which state to apply to JFrame
		/*
		if(state == 0)
		{
			changeState(0);
			add(name);
		}
		else if(state == 1)
		{
			changeState(1);
			add(top);
			
		}
		else if(state==2)
		{
			changeState(2);
			add(top2);
			
		}
		else if(state == 3)
		{
			changeState(3);
			add(top3);
			
		}
		else
		{
			changeState(4);
			add(top4);
			
		}*/
		
	}
	public void changeState(int state)
	{
		this.state = state;
		if(state == 0)
		{
			state_0();
		}
		else if(state == 1)
		{
			state_1();
			
		}
		else if(state == 2)
		{
			state_2();
		}
		else if(state == 3)
		{
			state_3();
		}
		else if(state == 4)
		{
			state_4();
		}
	}
	public void state_0()
	{
		name.setVisible(true);
		top.setVisible(false);
		top2.setVisible(false);
		top3.setVisible(false);
		top4.setVisible(false);
		this.add(name);
	}
	public void state_1()
	{
		name.setVisible(false);
		top.setVisible(true);
		top2.setVisible(false);
		top3.setVisible(false);
		top4.setVisible(false);
		this.add(top);
		
	}
	public void state_2()
	{
		name.setVisible(false);
		top.setVisible(false);
		top2.setVisible(true);
		top3.setVisible(false);
		top4.setVisible(false);
		this.add(top2);
		
	}
	public void state_3()
	{
		name.setVisible(false);
		top.setVisible(false);
		top2.setVisible(false);
		top3.setVisible(true);
		top4.setVisible(false);
		this.add(top3);
		
	}
	public void state_4()
	{
		name.setVisible(false);
		top.setVisible(false);
		top2.setVisible(false);
		top3.setVisible(false);
		top4.setVisible(true);
		this.add(top4);
	}
	
	public void actionPerformed(ActionEvent args0)
	{
		if(state == 1)
		{
			String s =(String)box.getSelectedItem();
		
			switch (s)
			{
			case "Option 1":
				JOptionPane.showMessageDialog(null, "You Chose Option 1!!");
				break;
			case "Option 2":
				JOptionPane.showMessageDialog(null, "You Chose Option 2!!");
				break;
			case "Option 3":
				JOptionPane.showMessageDialog(null, "You Chose Option 3!!");
				break;
			}
		}
		else if(state == 2)
		{
				if(select1.isSelected() & select2.isSelected() & select3.isSelected())
				{
					JOptionPane.showMessageDialog(null, "You Chose Option 1, 2, & 3!!");
				}
				else if(select1.isSelected() & select2.isSelected())
				{
					JOptionPane.showMessageDialog(null, "You Chose Option 1 & 2!!");
				}
				else if(select1.isSelected() & select3.isSelected())
				{
					JOptionPane.showMessageDialog(null, "You Chose Option 1 & 3!!");
				}
				else if(select2.isSelected() & select3.isSelected())
				{
					JOptionPane.showMessageDialog(null, "You Chose Option 2 & 3!!");
				}
				else if(select1.isSelected())
				{
					JOptionPane.showMessageDialog(null, "You Chose Option 1!!");
				}
				else if(select2.isSelected())
				{
					JOptionPane.showMessageDialog(null, "You Chose Option 2!!");
				}
				else if(select3.isSelected())
				{
					JOptionPane.showMessageDialog(null, "You Chose Option 3!!");
				}
			}
		else if(state == 3)
		{
			if(args0.getSource() == click)
			{
				JOptionPane.showMessageDialog(null, "You Chose Option 1!!");
			}
			else if(args0.getSource() == click1)
			{
				JOptionPane.showMessageDialog(null, "You Chose Option 2!!");
			}
			else if(args0.getSource() == click2)
			{
				JOptionPane.showMessageDialog(null, "You Chose Option 3!!");
			}
		}
		else if(state == 4)
		{
			String display = type.getText();
			JOptionPane.showMessageDialog(null, "Your answer was: "+ display);
		}
	}
	}

