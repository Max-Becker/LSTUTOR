import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Universe extends JPanel   {

	private static JPanel mainpan, Name;
	private static JSlider slider = new JSlider(JSlider.HORIZONTAL, 0, 4, 0);
	private static Tutor tutor = new Tutor();
	private static Assessor assessor = new Assessor();
	private static Companion companion = new Companion();
	private static JFrame frame = new JFrame("CSE360");
	//private static JEditorPane jeditorPane = tutor.runState();
	private static 	JPanel panel2 = new JPanel();
	public static void main (String[] args) {

		// creating Jframe and setting size		
		frame.setSize(700,700);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// creating Jpanel  with borderlayout
		mainpan = new JPanel();
		mainpan.setLayout(new BorderLayout());
	
		//Creates Panel with my name
		Name = new JPanel();
		Name.add(new JLabel("Juan Retiz"));
	
		//creating Jpanel with gridlayout for other panels 
		JPanel panel2 = new JPanel();
		panel2.setLayout(new GridLayout(2,2,3,3));
		panel2.setBackground(Color.cyan);
		
		//adds other panels to gridlayout
		
		panel2.add(tutor);
		panel2.add(assessor);
		panel2.add(companion);
		panel2.add(Name);

		//adds panel2 to center of main panel
		frame.add(panel2,BorderLayout.CENTER);
		
		//creating Jslider and adding to 
		slider.setPreferredSize(new Dimension(100,40));
		slider.setMajorTickSpacing(1);
		slider.setPaintLabels(true);
		slider.setPaintTicks(true);
		slider.addChangeListener(new listener());
		frame.add(slider, BorderLayout.SOUTH);
		frame.setVisible(true);
		System.out.println(slider.getValue());
	}

	private static class listener implements ChangeListener{

		@Override
		public void stateChanged(ChangeEvent e) {
			//if slider is adjusting it wont update
			if(!(slider.getValueIsAdjusting())){
			//takes input from slider and and changes state based on slider integer
				
				int place = slider.getValue();
			
				if(place == 0)
				{
					Name.setVisible(true);
					tutor.runState(place);
					assessor.changeState(place);
					try {
						companion.changeState(place);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
				}
				if(place == 1)
				{
					Name.setVisible(false);
					tutor.runState(place);
					assessor.changeState(place);
					try {
						companion.changeState(place);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
				}
				if(place == 2)
				{
					Name.setVisible(false);
					tutor.runState(place);
					assessor.changeState(place);
					try {
						companion.changeState(place);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
				}
				if(place == 3)
				{
					Name.setVisible(false);
					tutor.runState(place);
					assessor.changeState(place);
					try {
						companion.changeState(place);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
				}
				if(place == 4)
				{
					Name.setVisible(false);
					tutor.runState(place);
					assessor.changeState(place);
					try {
						companion.changeState(place);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
				}
			}
		}
	}

}
