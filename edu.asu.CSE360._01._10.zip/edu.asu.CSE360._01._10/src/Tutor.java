import javax.swing.*;
import javax.swing.text.Document;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;
import java.io.*;

/**
 * Created by MaxBe on 9/3/2017.
 */
public class Tutor extends JPanel {

    int state = 0;

    public Tutor ()
    {
        runState();
    }
    //Initialization
    public void runState()
    {
        this.removeAll();
        this.revalidate();
        this.repaint();
        String html = loadHTML(state);
        JEditorPane jEditorPane = createPane(html);
        jEditorPane.setOpaque(false);
        this.add(jEditorPane);
    }
    //changes the state
    public void runState(int state)
    {
        this.removeAll();
        this.revalidate();
        this.repaint();
        String html = loadHTML(state);
        JEditorPane jEditorPane = createPane(html);
        jEditorPane.setOpaque(false);
        this.add(jEditorPane);
    }
    //Loads the HTML file and returns it as a string. Checks for IO Exceptions
    private String loadHTML(int stateInput)
    {
        state = stateInput;
        if (state == 0)
        {
            String str = "Max Becker";
            return str;
        }
        	try{	
            File f = new File("resources/P" + state + ".html");
            BufferedReader br = new BufferedReader(new FileReader(f));
            String str = br.readLine();
            String html = "";
            while (str != null)
            {
                html+=str;
                str = br.readLine();
            }
            return html;
            
        }catch (IOException e) {
            e.printStackTrace();
                System.out.println("Could not find file, check again.");
        }
        String string = "Could not find file";
        return string;
    }
    //Creates the JEditorPane
    private JEditorPane createPane(String str)
    {
        JEditorPane jEditorPane = new JEditorPane();
        HTMLEditorKit htmlEditorKit = new HTMLEditorKit();
        jEditorPane.setEditorKit(htmlEditorKit);
        Document doc = htmlEditorKit.createDefaultDocument();
        jEditorPane.setDocument(doc);
        jEditorPane.setText(str);
        return jEditorPane;
    }
}
