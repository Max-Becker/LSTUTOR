import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.swing.Timer;

import javax.imageio.*;

/**
 * Title: Assignment #1 - Companion
 * Description: A companion JPanel for use in a larger tutoring program.
 * Author: Paul A. Nathan
 * Date: 9/5/2017
 */

public class Companion extends JPanel {
	private int c1, c2, c3,c4 = 0;
	public static JPanel myPanel, panel1, panel2, panel3, panel4, defaultPanel;
	ImageIcon icon, icon2,icon3,icon4;
	JLabel label1, label2, label3, label4;
	Timer timer;
	Thread th;
	ActionListener updateImage;

	// Constructor Method
	public Companion(){
		
		// DEFAULT CASE
		defaultPanel = new JPanel();
		defaultPanel.add(new JLabel("INVALID STATE"));
		// CASE 0
		myPanel = new JPanel();
		myPanel.add(new JLabel("Paul A. Nathan"));
		// CASE 1
		panel1 = new JPanel();
		ImageIcon icon = new ImageIcon("resources/Happy0.png", "");
		Image image = icon.getImage();
		Image newimg = image.getScaledInstance(300, 300,  java.awt.Image.SCALE_SMOOTH);
		icon = new ImageIcon(newimg);
		label1 = new JLabel(icon);
		panel1.add(label1);
		// CASE 2
		panel2 = new JPanel();
		ImageIcon icon2 = new ImageIcon("resources/Sad0.png", "");
		 image = icon2.getImage();
		 newimg = image.getScaledInstance(300, 300,  java.awt.Image.SCALE_SMOOTH);
		icon2 = new ImageIcon(newimg);
		label2 = new JLabel(icon2);
		panel2.add(label2);
		// CASE 3
		panel3 = new JPanel();
		ImageIcon icon3 = new ImageIcon("resources/Thinking0.png", "");
		image = icon3.getImage();
		newimg = image.getScaledInstance(300, 300,  java.awt.Image.SCALE_SMOOTH);
		icon3 = new ImageIcon(newimg);
		label3 = new JLabel(icon3);
		panel3.add(label3);
		// CASE 4
		panel4 = new JPanel();
		ImageIcon icon4 = new ImageIcon("resources/Worried0.png", "");
		image = icon4.getImage();
		newimg = image.getScaledInstance(300, 300,  java.awt.Image.SCALE_SMOOTH);
		icon4 = new ImageIcon(newimg);
		label4 = new JLabel(icon4);
		panel4.add(label4);

		// Add Panels to main panel
        this.add(myPanel);
        this.add(panel1);
        this.add(panel2);
        this.add(panel3);
        this.add(panel4);
        this.add(defaultPanel);
        
        // Set myPanel visible for initial state & set other panels invisible
        myPanel.setVisible(true);
     	panel1.setVisible(false);
	  	panel2.setVisible(false);
	  	panel3.setVisible(false);
	  	panel4.setVisible(false);
	  	defaultPanel.setVisible(false);
	}
	//ActionListeners that will change the images to provide the animation
	public class TActionListener1 implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			icon = new ImageIcon("resources/Happy" + c1 + ".png", "");
			Image image = icon.getImage();
			Image newimg = image.getScaledInstance(300, 300,  java.awt.Image.SCALE_SMOOTH);
			icon = new ImageIcon(newimg);
			label1.setIcon(icon);
			repaint();
			c1++;
			if (c1 > 4) {
				c1 = 0;
			}
		}
	}
	public class TActionListener2 implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			icon2 = new ImageIcon("resources/Sad" + c1 + ".png", "");
			Image image = icon2.getImage();
			Image newimg = image.getScaledInstance(300, 300,  java.awt.Image.SCALE_SMOOTH);
			icon2 = new ImageIcon(newimg);
			label2.setIcon(icon2);
			repaint();
			c1++;
			if (c1 > 4) {
				c1 = 0;
			}
		}
	}
	public class TActionListener3 implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			icon3 = new ImageIcon("resources/Thinking" + c1 + ".png", "");
			Image image = icon3.getImage();
			Image newimg = image.getScaledInstance(300, 300,  java.awt.Image.SCALE_SMOOTH);
			icon3 = new ImageIcon(newimg);
			label3.setIcon(icon3);
			repaint();
			c1++;
			if (c1 > 4) {
				c1 = 0;
			}
		}
	}
	public class TActionListener4 implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			icon4 = new ImageIcon("resources/Worried" + c1 + ".png", "");
			Image image = icon4.getImage();
			Image newimg = image.getScaledInstance(300, 300,  java.awt.Image.SCALE_SMOOTH);
			icon4 = new ImageIcon(newimg);
			label4.setIcon(icon4);
			repaint();
			c1++;
			if (c1 > 4) {
				c1 = 0;
			}
		}
	}

	// A method that checks the current slide-bar state and returns a JPanel
    // with the appropriate icon.
    public void changeState(int state) throws InterruptedException {
        // Check state value and run specific case
        switch (state) {
            case 0: // Set myPanel visible
					timer.stop();
					myPanel.setVisible(true);
                 	panel1.setVisible(false);
            	  	panel2.setVisible(false);
            	  	panel3.setVisible(false);
            	  	panel4.setVisible(false);
            	  	defaultPanel.setVisible(false);
            	  	break;
 
            case 1: // Set Happy Icon visible
					//timer.stop();
					th = new Thread();
					myPanel.setVisible(false);
            	  	panel1.setVisible(true);
            	  	panel2.setVisible(false);
            	  	panel3.setVisible(false);
            	  	panel4.setVisible(false);
            	  	defaultPanel.setVisible(false);
					timer = new Timer(500, new TActionListener1());
					timer.start();
            	  	break;
            	  	
            case 2: // Set Think Icon visible
					timer.stop();
					myPanel.setVisible(false);
            	  	panel1.setVisible(false);
            	  	panel2.setVisible(true);
            	  	panel3.setVisible(false);
            	  	panel4.setVisible(false);
            	  	defaultPanel.setVisible(false);
				timer = new Timer(500, new TActionListener2());
				timer.start();
            	  	break;
                
            case 3: // Set Worry Icon visible
					timer.stop();

					myPanel.setVisible(false);
                  	panel1.setVisible(false);
            	  	panel2.setVisible(false);
            	  	panel3.setVisible(true);
            	  	panel4.setVisible(false);
            	  	defaultPanel.setVisible(false);
				timer = new Timer(500, new TActionListener3());
				timer.start();
            	  	break;
            	  	
            case 4: // Set Sorry Icon visible
					timer.stop();

					myPanel.setVisible(false);
            		panel1.setVisible(false);
            		panel2.setVisible(false);
            		panel3.setVisible(false);
            		panel4.setVisible(true);
            		defaultPanel.setVisible(false);
				timer = new Timer(500, new TActionListener4());
				timer.start();
            		break;
            		
            default: // Declare new JLabel & set Default Panel visible
					timer.stop();

					myPanel.setVisible(false);
            		panel1.setVisible(false);
            		panel2.setVisible(false);
            		panel3.setVisible(false);
        	  		panel4.setVisible(false);
                    defaultPanel.setVisible(true);
                    break;
        }
    }
}
